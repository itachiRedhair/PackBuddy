var strings = {
    packPrompt: [
        "Let's pack",
        "Now pack",
        "Pack your"
    ]
}

function getRandomString(type) {
    let max = strings[type].length;
    var randomNumber = Math.floor(Math.random() * (max));
    console.log(randomNumber);
}

module.exports = { getRandomString }