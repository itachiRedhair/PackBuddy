'use strict';

let en = {
    "WELCOME_MSG": "Hi I am pack buddy",
    "ASK_NEW_TRIP": "Do you want me to help you with packing",
    "REPROMPT": "Please say something",

//NewTripHandler
    "ASK_ABOUT_TRIP":"Tell me about your trip",

    "Goodbye_MSG": "Good Bye"
};

module.exports = {
    "en-GB": {
        "translation": en
    }
}
