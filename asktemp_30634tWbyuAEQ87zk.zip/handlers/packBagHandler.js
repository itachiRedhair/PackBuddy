var Alexa = require("alexa-sdk");
var ddb = require('./../utilities/ddbController')
var getRandomString = require("./../utilities/randomStrings").getRandomString;

//constants
const states = require("./../constants").states;
const session = require("./../constants").session;
const packingStatus = require("./../constants").packingStatus;
const packingItemStatus = require("./../constants").packingItemStatus;

const packBagHandler = Alexa.CreateStateHandler(states.PACKING, {

    'NewSession': function () {
        const message = "Let's start packing. Shall we?";
        this.response.speak(message).listen("Do you want to start packing right now?");
        this.emit(":responseReady");
    },

    'packBagIntent': function () {
        let reprompt = "You can say yes or no";

        getPackingStatus.call(this);

        let item = this.attributes[session.CURRENT_PACKING_ITEM];

        switch (this.attributes[session.CURRENT_PACKING_STATUS]) {
            // case packingStatus.STARTED:
            //     this.response.speak("Let's start with " + item.name).listen(reprompt);
            //     break;
            case packingStatus.IN_PROGRESS:
                this.response.speak(getRandomString('packPrompt') + item.name).listen(reprompt);
                break;
            case packingStatus.COMPLETED:
                clearState.call(this);
                ddb.updatePackingList.call(this);
                this.response.speak("You are done");
                break;
            default:
                this.response.speak("There is some problem. Sorry for inconvenience.");
        }

        this.emit(":responseReady");
    },

    'AMAZON.HelpIntent': function () {
        const message = 'Try saying let\'s start packing';
        this.response.speak(message)
            .listen(message);
        this.emit(':responseReady');
    },

    'AMAZON.YesIntent': function () {

        switch (this.attributes[session.CURRENT_PACKING_STATUS]) {
            case packingStatus.NOT_STARTED:
                // this.attributes[session.CURRENT_PACKING_STATUS] === packingStatus.STARTED;
                this.emitWithState('packBagIntent');
                break;
            case packingStatus.IN_PROGRESS:
                var currentPackingItemKey = this.attributes[session.CURRENT_PACKING_ITEM_KEY];
                var currentPackingCategoryKey = this.attributes[session.CURRENT_PACKING_CATEGORY_KEY];
                this.attributes[session.CURRENT_PACKING_LIST][currentPackingCategoryKey][currentPackingItemKey]['status'] = packingItemStatus.PACKED;
                this.emitWithState('packBagIntent');
                break;
            default:
                this.response.speak("Maybe try something else. like saying help me packing");
                this.emit(":responseReady");
        }

    },

    'AMAZON.NoIntent': function () {

        switch (this.attributes[session.CURRENT_PACKING_STATUS]) {
            case packingStatus.NOT_STARTED:
                clearState.call(this);
                this.response.speak('Ok, see you next time!');
                this.emit(':responseReady');
                break;
            case packingStatus.IN_PROGRESS:
                var currentPackingItemKey = this.attributes[session.currentPackingItemKey];
                var currentPackingCategoryKey = this.attributes[session.CURRENT_PACKING_CATEGORY_KEY];
                this.attributes[session.CURRENT_PACKING_LIST][currentPackingCategoryKey][currentPackingItemKey]['status'] = packingItemStatus.NOT_INTERESTED;
                this.emitWithState('packBagIntent');
                break;
            default:
                this.response.speak("Maybe try something else. like saying help me packing");
                this.emit(":responseReady");
        }
    },

    'AMAZON.StopIntent': function () {
        clearState.call(this);
        ddb.updatePackingList.call(this);
        this.response.speak("Good Bye");
        this.emit(":responseReady");
    },

    'SessionEndedRequest': function () {
        clearState.call(this);
        ddb.updatePackingList.call(this);
        this.emit(':saveState', true)
    },

    'Unhandled': function () {
        const message = 'Try saying let start packing buddy';
        this.response.speak(message)
            .listen(message);
        this.emit(':responseReady');
    }
});

function clearState() {
    this.handler.state = '' // delete this.handler.state might cause reference errors
    delete this.attributes['STATE'];
}

function getPackingStatus() {

    var packingList = this.attributes[session.CURRENT_PACKING_LIST];
    console.log('in getPackingStatus current_packing_list', this.attributes[session.CURRENT_PACKING_LIST]);
    for (var categoryKey in packingList) {
        category = packingList[categoryKey]

        for (var itemKey in category) {
            item = category[itemKey];

            if (category[itemKey].status === packingItemStatus.NOT_PACKED) {
                this.attributes[session.CURRENT_PACKING_CATEGORY_KEY] = categoryKey;
                this.attributes[session.CURRENT_PACKING_ITEM_KEY] = itemKey;
                this.attributes[session.CURRENT_PACKING_ITEM] = item;
                console.log('in getPackingStatus current_packing_item--->', this.attributes[session.CURRENT_PACKING_ITEM]);
                this.attributes[session.CURRENT_PACKING_STATUS] = packingStatus.IN_PROGRESS;
                // return this.attributes['current_packing_status'];
                return;
            }

        }
    }

    this.attributes[session.CURRENT_PACKING_STATUS] = packingStatus.COMPLETED;
    // return this.attributes['current_packing_status'];
    return;
}

module.exports = packBagHandler;