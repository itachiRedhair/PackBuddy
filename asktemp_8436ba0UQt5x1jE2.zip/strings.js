'use strict';

let en = {
    "WELCOME_MSG": "Hi User",
    "Goodbye_MSG": "Good Bye"
};

module.exports = {
    "en-GB": {
        "translation": en
    }
}
